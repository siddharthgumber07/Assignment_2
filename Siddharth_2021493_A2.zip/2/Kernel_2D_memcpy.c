#define _GNU_SOURCE
#include <unistd.h>
#include <sys/syscall.h>
#include <stdio.h>
#include <stdlib.h>

#define SYS_kernel_2D_memcpy 451

int main() {
    float A[4][4] = {{1.2,3.4,5.6,7.8},
                            {8.7,4.5,3.0,5.4},
                            {3.0,0.1,7.2,3.1},
                            {9.8,4.2,6.3,5.7}};

    float B[4][4] = {{3.3,3.3,3.3,3.3},
                            {3.3,3.3,3.3,3.3},
                            {3.3,3.3,3.3,3.3},
                            {3.3,3.3,3.3,3.3}};

    printf("Matrix A(Before Syscall): \n");

    for (int i = 0; i < 4; i++){
        for (int j = 0; j < 4; j++){
            printf("%lf ", A[i][j]);
            }
        printf("\n");
    }

    printf("Matrix B(before syscall):\n");

    for (int i = 0; i < 4; i++){
        for (int j = 0; j < 4; j++){
            printf("%lf ", B[i][j]);
            }
        printf("\n");
    }

    int res = syscall(SYS_kernel_2D_memcpy, A, B, 4, 4);

    if(res < 0){
        printf("ERROR!! Couldn't perform syscall:(");
        exit(1);
    }

    printf("Matrix A(after Syscall):\n");

    for (int i = 0; i < 4; i++){
        for (int j = 0; j < 4; j++){
            printf("%lf ", A[i][j]);
            }
        printf("\n");
    }

    printf("Matrix B(after Syscall):\n");

    for (int i = 0; i < 4; i++){
        for (int j = 0; j < 4; j++){
            printf("%lf ", B[i][j]);
            }
        printf("\n");
    }
    return 0;
}