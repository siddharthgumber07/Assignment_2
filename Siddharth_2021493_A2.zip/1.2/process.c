#include<stdio.h>
#include<unistd.h>
#include<time.h>
#include<sys/wait.h>
#include<sys/types.h>
#include<sys/stat.h>
#include<sched.h>

pid_t pid1,pid2,pid3,pid4,pid5,pid6,pid7,pid8,pid9,pid10,pid11,pid12;
int status;
struct sched_param param;
double T[12];

void p1_default(){
  clock_t beg,end;
  beg=clock();
  pid1=fork();
  if(pid1==-1){
    printf("Child process couldn't be created!!!\n");
  }
  else if(pid1==0){
    sched_setscheduler(pid1, SCHED_OTHER,&param);
    execlp("make","make",NULL);
  }waitpid(pid1,&status,0);
  end=clock();
  double time=(double)(end-beg);
  T[0]=time;
  printf("Time taken by Process 1 by default priority : %f\n",time);
}

void p1_priority1(){
  clock_t beg,end;
  beg=clock();
  pid2=fork();
  if(pid2==-1){
    printf("UChild process couldn't be created!!!\n");
  }
  else if(pid2==0){
    param.sched_priority=1;
    sched_setscheduler(pid2, SCHED_OTHER,&param);
    execlp("make","make",NULL);
  }waitpid(pid2,&status,0);
   end=clock();
   double time=(double)(end-beg);
   T[1]=time;
  printf("Time taken by Process 1 by priority 1 : %f\n",time);
}

void p1_priority2(){
  clock_t beg,end;
  beg=clock();
  pid3=fork();
  if(pid3==-1){
    printf("Child process couldn't be created!!!\n");
  }
  else if(pid3==0){
    param.sched_priority=2;
    sched_setscheduler(pid3, SCHED_OTHER,&param);
    execlp("make","make",NULL);
  }waitpid(pid3,&status,0);
   end=clock();
  double time=(double)(end-beg);
  T[2]=time;
  printf("Time taken by Process 1 by priority 2 : %f\n",time);
}

void p1_priority3(){
  clock_t beg,end;
  beg=clock();
  pid4=fork();
  if(pid4==-1){
    printf("Child process couldn't be created!!!\n");
  }
  else if(pid4==0){
    param.sched_priority=3;
    sched_setscheduler(pid4, SCHED_OTHER,&param);
    execlp("make","make",NULL);
  }waitpid(pid4,&status,0);
   end=clock();
  double time=(double)(end-beg);
  T[3]=time;
  printf("Time taken by Process 1 by priority 3 : %f\n",time);
}

void p2_default(){
  clock_t beg,end;
  beg=clock();
  pid5=fork();
  if(pid5==-1){
    printf("Child process couldn't be created!!!\n");
  }
  else if(pid5==0){
    sched_setscheduler(pid5, SCHED_RR,&param);
    execlp("make","make",NULL);
  }waitpid(pid5,&status,0);
  end=clock();
  double time=(double)(end-beg);
  T[4]=time;
  printf("Time taken by Process 2 by default priority : %f\n",time);
}

void p2_priority1(){
  clock_t beg,end;
  beg=clock();
  pid6=fork();
  if(pid6==-1){
    printf("Child process couldn't be created!!!\n");
  }
  else if(pid6==0){
    param.sched_priority=1;
    sched_setscheduler(pid6, SCHED_RR,&param);
    execlp("make","make",NULL);
  }waitpid(pid6,&status,0);
   end=clock();
  double time=(double)(end-beg);
  T[5]=time;
  printf("Time taken by Process 2 by priority 1 : %f\n",time);
}

void p2_priority2(){
  clock_t beg,end;
  beg=clock();
  pid7=fork();
  if(pid7==-1){
    printf("Child process couldn't be created!!!\n");
  }
  else if(pid7==0){
    param.sched_priority=2;
    sched_setscheduler(pid7, SCHED_RR,&param);
    execlp("make","make",NULL);
  }waitpid(pid7,&status,0);
   end=clock();
  double time=(double)(end-beg);
  T[6]=time;
  printf("Time taken by Process 2 by priority 2 : %f\n",time);
}

void p2_priority3(){
  clock_t beg,end;
  beg=clock();
  pid8=fork();
  if(pid8==-1){
    printf("Child process couldn't be created!!!\n");
  }
  else if(pid8==0){
    param.sched_priority=3;
    sched_setscheduler(pid8, SCHED_RR,&param);
    execlp("make","make",NULL);
  }waitpid(pid8,&status,0);
   end=clock();
  double time=(double)(end-beg);
  T[7]=time;
  printf("Time taken by Process 2 by priority 3 : %f\n",time);
}

void p3_default(){
  clock_t beg,end;
  beg=clock();
  pid9=fork();
  if(pid9==-1){
    printf("Child process couldn't be created!!!\n");
  }
  else if(pid9==0){
    sched_setscheduler(pid9, SCHED_FIFO,&param);
    execlp("make","make",NULL);
  }waitpid(pid9,&status,0);
   end=clock();
  double time=(double)(end-beg);
  T[8]=time;
  printf("Time taken by Process 1 by default priority : %f\n",time);
}

void p3_priority1(){
  clock_t beg,end;
  beg=clock();
  pid10=fork();
  if(pid10==-1){
    printf("Child process couldn't be created!!!\n");
  }
  else if(pid10==0){
    param.sched_priority=1;
    sched_setscheduler(pid10, SCHED_FIFO,&param);
    execlp("make","make",NULL);
  }waitpid(pid10,&status,0);
  end=clock();
  double time=(double)(end-beg);
  T[9]=time;
  printf("Time taken by Process 1 by priority 1 : %f\n",time);
}

void p3_priority2(){
  clock_t beg,end;
  beg=clock();
  pid11=fork();
  if(pid11==-1){
    printf("Child process couldn't be created!!!\n");
  }
  else if(pid11==0){
    param.sched_priority=2;
    sched_setscheduler(pid11, SCHED_FIFO,&param);
    execlp("make","make",NULL);
  }waitpid(pid11,&status,0);
  end=clock();
  double time=(double)(end-beg);
  T[10]=time;
  printf("Time taken by Process 3 by priority 2 : %f\n",time);
}

void p3_priority3(){
  clock_t beg,end;
  beg=clock();
  pid12=fork();
  if(pid12==-1){
    printf("Child process couldn't be created!!!\n");
  }
  else if(pid12==0){
    param.sched_priority=3;
    sched_setscheduler(pid12, SCHED_FIFO,&param);
    execlp("make","make",NULL);
  }waitpid(pid12,&status,0);
  end=clock();
  double time=(double)(end-beg);
  T[11]=time;
  printf("Time taken by Process 3 by priority 3 : %f\n",time);
  
}

int main(){


    printf("Histogram for the process with default priority!!!!\n");
    for(int i=0;i<T[0];i++){
        printf("#");
    }
    printf("%f\n",T[0]);
    for(int i=0;i<T[4];i++){
        printf("#");
    }
    printf("%f\n",T[4]);
    for(int i=0;i<T[8];i++){
        printf("#");
    }
    printf("%f\n",T[8]);


    printf("Histogram for the process with priority 1!!!\n");
    for(int i=0;i<T[1];i++){
        printf("#");
    }
    printf("%f\n",T[1]);
    for(int i=0;i<T[5];i++){
        printf("#");
    }
    printf("%f\n",T[5]);
    for(int i=0;i<T[9];i++){
        printf("#");
    }
    printf("%f\n",T[9]);


    printf("Histogram for the process with priority 2!!!\n");
    for(int i=0;i<T[2];i++){
        printf("#");
    }
    printf("%f\n",T[2]);
    for(int i=0;i<T[6];i++){
        printf("#");
    }
    printf("%f\n",T[6]);
    for(int i=0;i<T[10];i++){
        printf("#");
    }
    printf("%f\n",T[10]);

    printf("Histogram for the process with priority 3!!!\n");
    for(int i=0;i<T[3];i++){
        printf("#");
    }
    printf("%f\n",T[3]);
    for(int i=0;i<T[7];i++){
        printf("#");
    }
    printf("%f\n",T[7]);
    for(int i=0;i<T[11];i++){
        printf("#");
    }
    printf("%f\n",T[11]);
    return 0;
}
