#include<stdio.h>
#include<sys/stat.h>
#include<sys/types.h>
#include<sys/wait.h>
#include<sched.h>
#include<unistd.h>
#include<time.h>

pid_t pid1,pid2,pid3,pid4,pid5,pid6,pid7,pid8,pid9,pid10,pid11,pid12;
int status;
struct sched_param param;

float A_default(){
  clock_t beg,end;
  beg=clock();
  pid1=fork();
  if(pid1==-1){
    printf("Child process couldn't be created!!!\n");
  }
  else if(pid1==0){
    sched_setscheduler(pid1, SCHED_OTHER,&param);
    execlp("make","make",NULL);
  }waitpid(pid1,&status,0);
  end=clock();
  float total_time=(float)(end-beg);
  return total_time;
}

float B_default(){
  clock_t beg,end;
  beg=clock();
  pid5=fork();
  if(pid5==-1){
    printf("Child process couldn't be created!!!\n");
  }
  else if(pid5==0){
    sched_setscheduler(pid5, SCHED_RR,&param);
    execlp("make","make",NULL);
  }waitpid(pid5,&status,0);
  end=clock();
  float total_time=(float)(end-beg);
  return total_time;
}

float C_default(){
  clock_t beg,end;
  beg=clock();
  pid9=fork();
  if(pid9==-1){
    printf("Child process couldn't be created!!!\n");
  }
  else if(pid9==0){
    sched_setscheduler(pid9, SCHED_FIFO,&param);
    execlp("make","make",NULL);
  }waitpid(pid9,&status,0);
  end=clock();
  float total_time=(float)(end-beg);
  return total_time;
}

float A_p1(){
  clock_t beg,end;
  beg=clock();
  pid2=fork();
  if(pid2==-1){
    printf("Child process couldn't be created!!!\n");
  }
  else if(pid2==0){
    param.sched_priority=1;
    sched_setscheduler(pid2, SCHED_OTHER,&param);
    execlp("make","make",NULL);
  }waitpid(pid2,&status,0);
  end=clock();
  float total_time=(float)(end-beg);
  return total_time;
}

float B_p1(){
  clock_t beg,end;
  beg=clock();
  pid6=fork();
  if(pid6==-1){
    printf("Child process couldn't be created!!!\n");
  }
  else if(pid6==0){
    param.sched_priority=1;
    sched_setscheduler(pid6, SCHED_RR,&param);
    execlp("make","make",NULL);
  }waitpid(pid6,&status,0);
  end=clock();
  float total_time=(float)(end-beg);
  return total_time;
}

float C_p1(){
  clock_t beg,end;
  beg=clock();
  pid10=fork();
  if(pid10==-1){
    printf("Child process couldn't be created!!!\n");
  }
  else if(pid10==0){
    param.sched_priority=1;
    sched_setscheduler(pid10, SCHED_FIFO,&param);
    execlp("make","make",NULL);
  }waitpid(pid10,&status,0);
  end=clock();
  float total_time=(float)(end-beg);
  return total_time;
}

float A_p2(){
  clock_t beg,end;
  beg=clock();
  pid3=fork();
  if(pid3==-1){
    printf("Child process couldn't be created!!!\n");
  }
  else if(pid3==0){
    param.sched_priority=2;
    sched_setscheduler(pid3, SCHED_OTHER,&param);
    execlp("make","make",NULL);
  }waitpid(pid3,&status,0);
  end=clock();
  float total_time=(float)(end-beg);
  return total_time;
}

float B_p2(){
  clock_t beg,end;
  beg=clock();
  pid7=fork();
  if(pid7==-1){
    printf("Child process couldn't be created!!!\n");
  }
  else if(pid7==0){
    param.sched_priority=2;
    sched_setscheduler(pid7, SCHED_RR,&param);
    execlp("make","make",NULL);
  }waitpid(pid7,&status,0);
  end=clock();
  float total_time=(float)(end-beg);
  return total_time;
}

float C_p2(){
  clock_t beg,end;
  beg=clock();
  pid11=fork();
  if(pid11==-1){
    printf("Child process couldn't be created!!!\n");
  }
  else if(pid11==0){
    param.sched_priority=2;
    sched_setscheduler(pid11, SCHED_FIFO,&param);
    execlp("make","make",NULL);
  }waitpid(pid11,&status,0);
  end=clock();
  float total_time=(float)(end-beg);
  return total_time;
}

float A_p3(){
  clock_t beg,end;
  beg=clock();
  pid4=fork();
  if(pid4==-1){
    printf("Child process couldn't be created!!!\n");
  }
  else if(pid4==0){
    param.sched_priority=3;
    sched_setscheduler(pid4, SCHED_OTHER,&param);
    execlp("make","make",NULL);
  }waitpid(pid4,&status,0);
  end=clock();
  float total_time=(float)(end-beg);
  return total_time;
}

float B_p3(){
  clock_t beg,end;
  beg=clock();
  pid8=fork();
  if(pid8==-1){
    printf("Child process couldn't be created!!!\n");
  }
  else if(pid8==0){
    param.sched_priority=3;
    sched_setscheduler(pid8, SCHED_RR,&param);
    execlp("make","make",NULL);
  }waitpid(pid8,&status,0);
  end=clock();
  float total_time=(float)(end-beg);
  return total_time;
}

float C_p3(){
  clock_t beg,end;
  beg=clock();
  pid12=fork();
  if(pid12==-1){
    printf("Child process couldn't be created!!!\n");
  }
  else if(pid12==0){
    param.sched_priority=3;
    sched_setscheduler(pid12, SCHED_FIFO,&param);
    execlp("make","make",NULL);
  }waitpid(pid12,&status,0);
  end=clock();
  float total_time=(float)(end-beg);
  return total_time;
}

int main(){
  float t1=A_default();
  float t2=A_p1();
  float t3=A_p2();
  float t4=A_p3();
  float t5=B_default();
  float t6=B_p1();
  float t7=B_p2();
  float t8=B_p3();
  float t9=C_default();
  float t10=C_p1();
  float t11=C_p2();
  float t12=C_p3();
  
  printf("\n\nPROCESS-A DEFAULT:");
  for(int i=0;i<t1;i++){
    printf("#");
  }
  printf(" %f\n",t1);

  printf("PROCESS-B DEFAULT:");
  for(int i=0;i<t5;i++){
    printf("#");
  }
  printf(" %f\n",t5);

  printf("PROCESS-C DEFAULT:");
  for(int i=0;i<t9;i++){
    printf("#");
  }
  printf(" %f\n",t9);
  //////////////////////////////////////////////////////////////////////

  printf("PROCESS-A PRIORITY-1:");
  for(int i=0;i<t2;i++){
    printf("#");
  }
  printf(" %f\n",t2);

  printf("PROCESS-B PRIORITY-1:");
  for(int i=0;i<t6;i++){
    printf("#");
  }
  printf(" %f\n",t6);

  printf("PROCESS-C PRIORITY-1:");
  for(int i=0;i<t10;i++){
    printf("#");
  }
  printf(" %f\n",t10);

/////////////////////////////////////////////////////////////////////

  printf("PROCESS-A PRIORITY-2:");
  for(int i=0;i<t3;i++){
    printf("#");
  }
  printf(" %f\n",t3);


  printf("PROCESS-B PRIORITY-2:");
  for(int i=0;i<t7;i++){
    printf("#");
  }
  printf(" %f\n",t7);

  printf("PROCESS-C PRIORITY-2:");
  for(int i=0;i<t11;i++){
    printf("#");
  }
  printf(" %f\n",t11);


  printf("PROCESS-A PRIORITY-3:");
  for(int i=0;i<t4;i++){
    printf("#");
  }
  printf(" %f\n",t4);


  printf("PROCESS-B PRIORITY-3:");
  for(int i=0;i<t8;i++){
    printf("#");
  }
  printf(" %f\n",t8);
  

  printf("PROCESS-C PRIORITY-3:");
  for(int i=0;i<t12;i++){
    printf("#");
  }
  printf(" %f\n",t12);
  return 0;
}