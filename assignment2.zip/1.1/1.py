from matplotlib import pyplot as plt
import numpy as np

f=open("text.txt","r")
d1=f.readline()
a1=f.readline()
a2=f.readline()
a3=f.readline()
a4=f.readline()
d2=f.readline()
b1=f.readline()
b2=f.readline()
b3=f.readline()
b4=f.readline()
d3=f.readline()
c1=f.readline()
c2=f.readline()
c3=f.readline()
c4=f.readline()

DATA={ "Default_1":d1,
"Priority_a1":a1,
"Priority_a2":a2,
"Priority_a3":a3,
"Priority_a4":a4,
"Default_2":d2,
"Priority_b1":b1,
"Priority_b2":b2,
"Priority_b3":b3,
"Priority_b4":b4,
"Default_3":d3,
"Priority_c1":c1,
"Priority_c2":c2,
"Priority_c3":c3,
"Priority_c4":c4,
}

x=list(DATA.keys())
y=list(DATA.values())

plot=plt.figure(figsize=(100,100))
plt.bar(x,y,color="blue",width=0.7)

plt.xlabel("Priorities---")
plt.ylabel("Time----")
plt.title("For Thread: ")
plt.show()
  
plt.show()
