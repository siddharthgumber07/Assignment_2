#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <sys/resource.h>
#include <unistd.h>
#include <pthread.h>
#include <time.h>


void *A(){
  for(long long int i = 0; i<4294967296; i++){   
  }
}
void *B(){
  for(long long int i = 0; i<4294967296; i++){
  }
}
void *C(){
  for(long long int i = 0; i<4294967296; i++){
  }
}


int main(){
  struct sched_param param;
	pthread_t thread1, thread2, thread3;
  double d1,d2,d3,d4,d5,d6,d7,d8,d9;
  clock_t t1,t2,t3,t4,t5,t6,t7,t8,t9,c1,c2,c3,c4,c5,c6,c7,c8,c9;
  
  FILE * file;
  file = fopen("text.txt","w");
  t1=clock();
  pthread_create(&thread1, NULL, A, NULL);
  pthread_create(&thread1, NULL, B, NULL);
  pthread_create(&thread1, NULL, C, NULL);
  pthread_setschedparam(thread1, SCHED_OTHER, &param);
  pthread_join(thread1, NULL);
  
  c1=clock();
  d1=(double)(c1-t1);
  printf("Time taken in running thread 1: %f\n",d1/1000000);
  fprintf(file," %f\n",d1/1000000);
  for(int num = 1; num<=4; num++){
    printf("Priority: %d ",num);
    t2=clock();
    pthread_setschedprio(thread1,num);
    pthread_join(thread1, NULL);
    c2=clock();
    d2=(double)(c2-t2);
    printf("Time taken in running thread 1: %f\n",d2/1000000);
    fprintf(file," %f\n",d2/1000000);
  }
  printf("\n");
  t3=clock();
  pthread_create(&thread2, NULL, A, NULL);
  pthread_create(&thread2, NULL, B, NULL);
  pthread_create(&thread2, NULL, C, NULL);
  pthread_setschedparam(thread2, SCHED_RR, &param);
  pthread_join(thread2, NULL);
  c3=clock();
  d3=(double) (c3-t3);
  printf("Time taken in running thread 2: %f\n",d3/1000000);
  fprintf(file,"%f\n",d3/1000000);

  for(int num = 1; num<=4; num++){
    printf("Priority: %d ",num);
    t4=clock();
    pthread_setschedprio(thread2,num);
    pthread_join(thread2, NULL);
    c4=clock();
    d4=(double)(c4-t4);
    printf("Time taken in running thread 2: %f\n",d4/1000000);
    fprintf(file,"%f\n",d4/1000000);  
  }
    printf("\n");
  t5=clock();
  pthread_create(&thread3, NULL, A, NULL);
  pthread_create(&thread3, NULL, B, NULL);
  pthread_create(&thread3, NULL, C, NULL);
  pthread_setschedparam(thread3, SCHED_FIFO, &param);
  pthread_join(thread3, NULL);
  c5=clock();
  d5=(double)(c5-t5);
  printf("Time taken in running thread 3: %f\n",d5/1000000);
  fprintf(file," %f\n",d5/1000000);

  for(int num = 1; num<=4; num++){
    printf("Priority: %d ",num);
    t6=clock();
    pthread_setschedprio(thread3,num);
    pthread_join(thread3, NULL);
    c6=clock();
    d6=(double)(c6-t6);
    printf("Time taken in running thread3: %f\n",d6/1000000);
    fprintf(file,"%f\n",d6/1000000); 
  }
  fclose(file);
	exit(0);
}
